﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Contacts.API.Repositories;
using Contacts.Api.Models.Client.Entities;
using Contacts.Api.Models.Client.Mappers;
using Contacts.API.Model.Forms;

namespace Contacts.API.core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthentificationController : ControllerBase
    {

        private readonly IAuthRepository<User> _repository;


        public AuthentificationController(IAuthRepository<User> repository)
        {
            _repository = repository;
        }



        [HttpPost]
        public IActionResult Register([FromBody] RegisterForm form)
        {
            User user = new User(form.LastName, form.FirstName, form.Email, form.Passwd);
            if (_repository.Register(user))
                return Ok();

            return BadRequest();
        }

       
        [HttpGet]
        public User Get()
        {

            return new User("lastname", "firstname", "email", "pswd");

        }



    }
}
