﻿using Contacts.Api.Models.Client.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GlobalEntities = Contacts.Api.Models.Global.Entities;

namespace Contacts.Api.Models.Client.Mappers
{
    internal static class Mappers
    {
        public static GlobalEntities.User ToGlobal(this User entity)
        {
            return new GlobalEntities.User()
            {
                Id = entity.Id,
                LastName = entity.LastName,
                FirstName = entity.FirstName,
                Email = entity.Email,
                Pswd = entity.Passwd
            };
        }

        public static User ToClient(this GlobalEntities.User entity)
        {
            return new User(entity.Id, entity.LastName, entity.FirstName, entity.Email);
        }
      
    }
}
