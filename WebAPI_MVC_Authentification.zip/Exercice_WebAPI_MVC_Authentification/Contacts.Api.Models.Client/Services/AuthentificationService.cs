﻿using Contacts.Api.Models.Client.Entities;
using GlobalEntities = Contacts.Api.Models.Global.Entities;

using Contacts.API.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contacts.Api.Models.Client.Mappers;

namespace Contacts.Api.Models.Client.Services
{
    public class AuthentificationService : IAuthRepository<User>
    {

        public IAuthRepository<GlobalEntities.User> _globalAuthenticationRepo;


        public AuthentificationService(IAuthRepository<GlobalEntities.User> GlobalAuthenticationRepo)
        {
            _globalAuthenticationRepo = GlobalAuthenticationRepo;
        }



        public User Login(string email, string pswd)
        {
            return _globalAuthenticationRepo.Login(email, pswd).ToClient();
        }

        public bool Register(User user)
        {
            bool result = _globalAuthenticationRepo.Register(user.ToGlobal());
            user.Passwd = null;
            return result;
        }
    }
}
