﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contacts.API.Repositories
{
    public interface IAuthRepository<TUser>
    {
        bool Register(TUser user);
        TUser Login(string email, string pswd);
    }
}
