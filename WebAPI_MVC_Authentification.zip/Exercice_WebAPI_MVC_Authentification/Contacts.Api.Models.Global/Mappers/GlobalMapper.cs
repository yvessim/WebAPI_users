﻿using Contacts.Api.Models.Global.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contacts.Api.Models.Global.Mappers
{
    internal static class GlobalMapper
    {

        internal static User ToUser(this IDataRecord dataRecord)
        {
            return new User() { Id = (int)dataRecord["Id"], LastName = (string)dataRecord["LastName"], FirstName = (string)dataRecord["FirstName"], Email = (string)dataRecord["Email"] };
        }


    }
}
