﻿using ConnectionTool;
using ConnectionTool.DataBase;
using Contacts.Api.Models.Global.Entities;
using Contacts.Api.Models.Global.Mappers;
using Contacts.API.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contacts.Api.Models.Global.Services
{
    public class AuthentificationService : IAuthRepository<User>
    {

        private Connection _con;


        public AuthentificationService(Connection con)
        {
            _con = con;
        }

        public User Login(string email, string pswd)
        {
            Command com = new Command("SP_AuthenticateUser", true);
            com.AddParameter("Email",email);
            com.AddParameter("Passwd", pswd);

            return _con.ExecuteReader(com, (dr) => dr.ToUser()).SingleOrDefault();
        }

        public bool Register(User user)
        {
            Command com = new Command("SP_RegisterUser", true);
            com.AddParameter("LastName", user.LastName);
            com.AddParameter("FirstName", user.FirstName);
            com.AddParameter("Email", user.Email);
            com.AddParameter("Passwd", user.Pswd);

            int rows = _con.ExecuteNonQuery(com);
            user.Pswd = null;
            return rows == 1;
        }
    }
}
